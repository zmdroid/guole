﻿for(var i = 0; i < 113; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u102'] = 'center';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u38'] = 'top';
u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业平台.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u104'] = 'center';
u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('鲜果切.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u106'] = 'top';
u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('果盘.html');

}
});

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u78'] = 'top';
u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登录.html');

}
});
gv_vAlignTable['u94'] = 'top';
u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册.html');

}
});
gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u91'] = 'center';gv_vAlignTable['u35'] = 'center';
u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('鲜果.html');

}
});
gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u80'] = 'top';