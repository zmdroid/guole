﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m),_(c,n,e,f,g,o),_(c,p,e,f,g,q,i,[_(c,r,e,f,g,s)]),_(c,t,e,f,g,u),_(c,v,e,f,g,w),_(c,x,e,f,g,y),_(c,z,e,f,g,A,i,[_(c,B,e,f,g,C),_(c,D,e,f,g,E),_(c,F,e,f,g,G),_(c,H,e,f,g,I),_(c,J,e,f,g,K),_(c,L,e,f,g,M)]),_(c,N,e,f,g,O,i,[_(c,P,e,f,g,Q),_(c,R,e,f,g,S),_(c,T,e,f,g,U)])])]);}; 
var b="rootNodes",c="pageName",d="果趣吧",e="type",f="Wireframe",g="url",h="果趣吧.html",i="children",j="首页",k="首页.html",l="登录",m="登录.html",n="注册",o="注册.html",p="鲜果",q="鲜果.html",r="鲜果详细页",s="鲜果详细页.html",t="果盘",u="果盘.html",v="鲜果切",w="鲜果切.html",x="企业平台",y="企业平台.html",z="个人中心",A="个人中心.html",B="信息中心",C="信息中心.html",D="账户信息",E="账户信息.html",F="密码管理",G="密码管理.html",H="账户余额",I="账户余额.html",J="我的订单",K="我的订单.html",L="收货地址",M="收货地址.html",N="订单流程",O="订单流程.html",P="购物车",Q="购物车.html",R="订单信息确认页",S="订单信息确认页.html",T="成功提交订单",U="成功提交订单.html";
return _creator();
})();
