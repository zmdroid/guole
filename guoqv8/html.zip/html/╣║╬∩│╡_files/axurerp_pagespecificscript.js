﻿for(var i = 0; i < 57; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u30'] = 'top';
u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册.html');

}
});
gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u14'] = 'top';
u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登录.html');

}
});
gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u34'] = 'top';