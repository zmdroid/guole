﻿for(var i = 0; i < 70; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u38'] = 'top';
u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('企业平台.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u66'] = 'top';
u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('鲜果切.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u50'] = 'top';
u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('果盘.html');

}
});

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('首页.html');

}
});
gv_vAlignTable['u54'] = 'top';
u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('登录.html');

}
});

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('注册.html');

}
});
gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u35'] = 'center';
u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('鲜果.html');

}
});
gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u29'] = 'top';